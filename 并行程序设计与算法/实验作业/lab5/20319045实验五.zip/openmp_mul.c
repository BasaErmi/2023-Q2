#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<omp.h>


int M,N,K;

double *A;
double *B;
double *C;

void init_Mat(int M,int N,int K){
    srand(111);
    A = (double*) malloc(M * N * sizeof(double));
    B = (double*) malloc(N * K * sizeof(double));
    C = (double*) malloc(M * K * sizeof(double));
    for (int m=0;m<M;m++){
        for(int n=0;n<N;n++){
            A[m*N+n]=(double)(rand()%1000/10.0);
        }
    }
    for (int n=0;n<N;n++){
        for(int k=0;k<K;k++){
            B[n*K+k]=(double)(rand()%1000/10.0);
        }
    }
    for (int m=0;m<M;m++){
        for(int k=0;k<K;k++){
            C[m*K+k]=0;
        }
    }
} 


void open_mul(){
    #pragma omp parallel for num_threads(Thread_NUM) schedule(static, 1)
    for(int m=0;m<M;m++){
        for(int n=0;n<N;n++){
            for(int k=0;k<K;k++){
                C[m*K+k]+=A[m*N+n]*B[n*K+k];
            }
        }
    }
}


void serial_gemm(){
    for(int m=0;m<M;m++){
        for(int n=0;n<N;n++){
            for(int k=0;k<K;k++){
                C[m*K+k]+=A[m*N+n]*B[n*K+k];
            }
        }
    }
}


void print_mat(int row,int col,double * matrix){
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            printf("%.2f \t",matrix[i*col+j]);
        }
        printf("\n");
    }
}

int main(int argc, char * argv[] ){
    M=atoi(argv[1]);
    N=atoi(argv[2]);
    K=atoi(argv[3]);
    Thread_NUM=atoi(argv[4]);

    clock_t start_time,end_time;

    init_Mat(M,N,K);

    start_time=clock();
    open_mul();
    end_time=clock();
    double using_time=(double)(end_time-start_time)/CLOCKS_PER_SEC;

    printf("result:\n");
//    print_mat(M,K,C);
    printf("using time: %f s\n", using_time);

    free(A);
    free(B);
    free(C);

    return 0;
}