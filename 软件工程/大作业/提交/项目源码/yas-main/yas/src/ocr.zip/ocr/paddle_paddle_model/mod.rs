mod model;
mod preprocess;

pub use model::PPOCRModel;
pub use model::ppocr_model;
pub use model::PPOCRChV4RecInfer;
